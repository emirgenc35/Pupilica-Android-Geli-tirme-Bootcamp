package com.example.navigationodev

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.navigationodev.databinding.FragmentSayfaYBinding

class SayfaYFragment : Fragment() {

    private lateinit var tasarim: FragmentSayfaYBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        tasarim = FragmentSayfaYBinding.inflate(inflater, container, false)
        return tasarim.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Geri tuşu basıldığında ana sayfaya geç
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            findNavController().navigate(R.id.action_sayfaYFragment_to_anaSayfaFragment)
        }
    }
}
